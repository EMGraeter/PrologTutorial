/* Welcome to my example file!
I wrote this for homework when I was first learning Prolog, but I thought it was interesting,
so I decided to include it in this tutorial.
I'm not going to comment as much in this file because it assumes you've read the tutorial file first.
Enjoy! */

% list of facts

dc.
marvel.

titans(robin).
titans(starfire).
titans(beastBoy).
titans(cyborg).
titans(raven).

jla(superman).
jla(batman).
jla(martianManhunter).
jla(cyborg).
jla(theFlash).
jla(greenLantern).
jla(wonderWoman).
jla(aquaman).
jla(blackCanary).
jla(greenArrow).

avengers(ironMan).
avengers(thor).
avengers(hulk).
avengers(blackWidow).
avengers(hawkeye).
avengers(captainAmerica).

teamRed(spiderman).
teamRed(deadpool).
teamRed(daredevil).

% list of rules

% query the member and it gives you the team
% query the team and it gives you all the members

team(X, Y) :- X==titans, titans(Y).
team(X, Y) :- X=titans, titans(Y).
team(X, Y) :- X==jla, jla(Y).
team(X, Y) :- X=jla, jla(Y).
team(X, Y) :- X==avengers, avengers(Y).
team(X, Y) :- X=avengers, avengers(Y).
team(X, Y) :- X==teamRed, teamRed(Y).
team(X, Y) :- X=teamRed, teamRed(Y).

% query if two people are teammates

teammates(X, Y) :- titans(X), titans(Y).
teammates(X, Y) :- jla(X), jla(Y).
teammates(X, Y) :- avengers(X), avengers(Y).
teammates(X, Y) :- teamRed(X), teamRed(Y).

% query the person and it will tell you if they are Marvel or DC

industry(X, Y) :- X=marvel, (avengers(Y); teamRed(Y)).
industry(X, Y) :- X=dc, (titans(Y); jla(Y)).