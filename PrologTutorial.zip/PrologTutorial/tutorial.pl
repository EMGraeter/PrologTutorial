/* Welcome to my Prolog tutorial!
This may look like a lot of code, but it's really just heavily commented for your learning pleasure.
in case you haven't already noticed this is how you write multi-line comments in Prolog.
Prolog will ignore every character after the first bracket until is reaches this -> */

% One-line comments are made with the percent (%) character like this.

% Here we'll state a few facts
% Each statement in Prolog needs to end with a period (.) or full stop

battle.
avengers(tonyStark).
avengers(steveRogers).
shield(nickFury).
shield(philCoulson).

/* It's important to note that all these terms start with lowercase letters.
Only variables start with uppercase letters.
Typically there will be two terminals when coding with Prolog, one to put the knowledge base in
and one to ask queries in. This file is written to act as a knowledge base but you can copy the queries I've written here.

?- avengers(philCoulson).

This would return false because no Phil is not in the avengers.

?- battle.

This would return true because yes there is a batlle going on.

?- avengers(X).

This would return X = tonyStark and X = .
This is an example of variable use.
The compiler knows that X is a variable to be replaced by the answer because the first character of the word is capitalised.
If we instead queried ?- avengers(x). Prolog would return false. */

% Let's make our facts a bit more complicated.

geniuses(tonyStark, bruceBanner).
theRealEnemiesHere(thanos, theChitauri).
brothers(thor, loki).

/* In Prolog the comma (,) acts as a way of saying 'and'.
You can link as many of these statements together as you want.

arbitrayFact(hiThere1, hiThere2, hiThere3, ..., hiThereK). */

% let's try rules now

fights(steveRogers, loki).
fights(tonyStark, loki).
fights(thor, loki).
lokiSays(iAmNotYourBrother). :- fights(thor, loki); fights(loki, thor).

/* The turnstyle (:-) can be read as 'if' and the semicolon (;) can be read as 'or'.
This states that Loki says "I am not your brother." if Thor fights Loki or if Loki fights Thor.
Let's try another query.

?- lokiSays(iAmNotYourBrother).

This returns true because Prolog can deduce it from the given facts and rules.
This is what makes Prolog so useful and intelligent enough to be considered an AI language, but it gets better. */

% Variables can also be used in rules.

prince(X) :- brothers(thor, X).
friends(X, Y) :- avengers(X), avengers(Y).
coworkers(X, Y) :- shield(X), shield(Y).
teamUp(X, Y) :- fights(X, Z), fights(Y, Z).

/* These rules state that anyone who is Thor's borther is also a prince,
if two people are a part of the Avengers then they are friends,
if two people work for SHIELD then they are coworkers,
and if two people are fighting the same person then they will team up.

Now we can ask a few more queries.

?- prince(loki).
?- friends(tonyStark, steveRogers).
?- coworkers(nickFury, philCoulson).
?- teamUp(steveRogers, thor).

all these return true.
If we ask ?- teamUp(tonyStark, nickFury). though it will return false
because we haven't stated that Fury and Tony are fighting the same person. */

/*Obviously there's a lot of information missing here.
I didn't include every fact about the Avengers because I felt it wasn't needed to display Prolog's syntax. */